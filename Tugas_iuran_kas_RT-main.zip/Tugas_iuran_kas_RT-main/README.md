# IURAN_KAS_RT

<Hr>

UJIAN AKHIR SEMESTER<br>
PEMROGRAMAN WEB<br>
TEKNIK INFORMATIKA<br>
UNIVERSITAS PELITA BANGSA<br>

| NAMA :| Dutha Khris Phasarilla : 312110611 |
:| Sri Kartini : 312110435|
:| Afra Nesya Apriyanthi : 312110614 |
:| Farida Prasetyaning Rahayu : 312110605 |
:| Viena Dwi Putri Maulina : 312110469 |

| KELAS :| TI.21.C1 |
| DOSEN :| Agung Nugroho,S.Kom.,M.Kom |

<Hr>

# Tugas Project Ujian Akhir Semester

**Membuat Aplikasi Pengelolaan Iuran KAS RT**<br>
• membuat code program PHP menggunakan Framework Codeigniter 4

<hr>

link demo :

link google drive/youtube : https://youtu.be/Popoj4MtXjI

<hr>
  
  **``Membuat Database``**
  
  
   **`` Konfigurasi koneksi database & Membuat Program php``**
  
  ![12_UAS_Iuran_KAS_RTWeb](Gambar/09_Gambar_koneksi.jpg)
  
   ** ``XAMPP Control Panel `` **
    
  ![12_UAS_Iuran_KAS_RTWeb](Gambar/10_Gambar_xampp.jpg)
  
   ** ``Menjalankan CLI (Command Line Interface)``**
  
  #cd > direktori kerja project dibuat (C:\xampp\htdocs\lab12_Iuran_KAS_RT_php_ci)
  
  Perintah yang dapat dijalankan untuk memanggil CLI Codeigniter adalah: ``php spark`` dan 
  
  ``php spark serve``
  
   Selanjutnya buka browser kembali, dengan mengakses url : <http://localhost:8080/warga>
   
   
 ![12_UAS_Iuran_KAS_RTWeb](Gambar/02_Gambar_Warga.jpg)
  
 <hr>
  
  Cukup Sekian Penjelasan Dari saya
  
  **TERIMAKASIH**
<hr>

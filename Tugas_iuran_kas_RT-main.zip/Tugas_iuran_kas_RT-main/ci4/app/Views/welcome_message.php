<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
</head>
<body>
<?= $this->include('template/header_view'); ?>
<div class="container pt-5">
<hr>
<div class="row">
<div class="container">
<center><h1 b>Selamat Datang di Aplikasi Pengelolaan KAS RT
            </div>
            <br>
	
        </div>
	</body>
</html>
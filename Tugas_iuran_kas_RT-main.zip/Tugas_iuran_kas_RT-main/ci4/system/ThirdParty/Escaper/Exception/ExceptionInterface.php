<?php

declare(strict_types=1);

namespace Laminas\Escaper\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}

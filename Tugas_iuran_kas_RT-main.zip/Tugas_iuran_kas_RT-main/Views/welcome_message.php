<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
</head>
<body>
<?= $this->include('template/header_view'); ?>
<div class="container pt-5">
<hr>
<div class="row">
<div class="container">
<center><h1 b>Selamat Datang di Aplikasi Pengelolaan KAS RT
            </div>
        </div></center>
<br><br><br><br><br>

        <center> <div>
        <h3 b>Dibuat Oleh:</h>
               <div class="container pt-4">
               <h1>Sri Kartini:312110435</h>
               <h1>Dutha Khris P: 312110611</h>
               <h1>Afra Nesya Apriyanti : 312110614 </h>
               <h1>Farida Prasetyaning Rahayu : 312110605</h>
               <h1>Viena Dwi Putri Maulina : 312110469</h>
                </p>
            </div>
</div></center>
            <br>
	</body>
</html>